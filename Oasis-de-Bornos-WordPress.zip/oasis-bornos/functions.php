<?php
/**
 * Oasis de Bornos — maquette WordPress importable.
 * L’import se déclenche uniquement par le bouton de l’administration.
 * Il crée des brouillons, ne publie rien et ne change pas la visibilité du site.
 */
defined('ABSPATH') || exit;

add_action('after_setup_theme', function () {
    add_theme_support('editor-styles');
    add_editor_style('style.css');
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('oasis-bornos', get_stylesheet_uri(), array(), '1.2.0');
    wp_enqueue_script('oasis-demo-form', get_theme_file_uri('assets/demo-form.js'), array(), '1.2.0', true);
});

function oasis_demo_manifest() {
    return json_decode(file_get_contents(get_theme_file_path('data/pages.json')), true) ?: array();
}

function oasis_demo_page_url($slug) {
    $pages = get_option('oasis_demo_pages', array());
    $post = isset($pages[$slug]) ? get_post((int) $pages[$slug]) : null;
    if ($post && 'trash' !== $post->post_status) {
        return 'publish' === $post->post_status ? get_permalink($post) : get_preview_post_link($post);
    }
    return home_url('/');
}

function oasis_demo_content($file) {
    $file = basename($file);
    $path = get_theme_file_path('data/' . $file);
    if (!is_readable($path)) {
        return '';
    }
    $content = file_get_contents($path);
    $content = preg_replace_callback('/\{\{ASSET:([^}]+)\}\}/', function ($matches) {
        return esc_url(get_theme_file_uri('assets/images/' . basename($matches[1])));
    }, $content);
    $content = preg_replace_callback('/\{\{PAGE:([^}]+)\}\}/', function ($matches) {
        return esc_url(oasis_demo_page_url(sanitize_title($matches[1])));
    }, $content);
    return $content;
}

add_action('init', function () {
    register_block_pattern_category('oasis-bornos', array('label' => 'Oasis de Bornos'));
    $patterns = oasis_demo_manifest();
    $patterns[] = array('slug' => 'header', 'title' => 'En-tête Oasis', 'file' => 'header.html');
    $patterns[] = array('slug' => 'footer', 'title' => 'Pied de page Oasis', 'file' => 'footer.html');
    foreach ($patterns as $pattern) {
        register_block_pattern('oasis-bornos/' . $pattern['slug'], array(
            'title' => $pattern['title'],
            'categories' => array('oasis-bornos'),
            'content' => oasis_demo_content($pattern['file']),
            'inserter' => !in_array($pattern['slug'], array('header', 'footer'), true),
        ));
    }
});

add_shortcode('oasis_contact', function () {
    return file_get_contents(get_theme_file_path('data/demo-form.html'));
});

add_action('admin_menu', function () {
    add_theme_page('Maquette Oasis de Bornos', 'Maquette Oasis', 'manage_options', 'oasis-demo', 'oasis_demo_admin_page');
});

function oasis_demo_admin_page() {
    if (!current_user_can('manage_options') || !current_user_can('edit_pages')) {
        return;
    }
    $pages = get_option('oasis_demo_pages', array());
    $message = get_transient('oasis_demo_result_' . get_current_user_id());
    if ($message) {
        delete_transient('oasis_demo_result_' . get_current_user_id());
    }
    ?>
    <div class="wrap">
        <h1>Maquette Oasis de Bornos</h1>
        <p>Importer les 17 pages de présentation comme brouillons, puis les ouvrir avec « Prévisualiser ».</p>
        <p>Les pages existantes ne sont pas écrasées. Aucun réglage de visibilité ni de page d’accueil n’est modifié.</p>
        <?php if ($message) : ?>
            <div class="notice notice-info"><p><?php echo esc_html($message); ?></p></div>
        <?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="oasis_demo_import">
            <?php wp_nonce_field('oasis_demo_import'); ?>
            <?php submit_button('Importer les pages en brouillon'); ?>
        </form>
        <?php if ($pages) : ?>
            <table class="widefat striped" style="max-width:900px">
                <thead><tr><th>Page</th><th>Statut</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach (oasis_demo_manifest() as $item) :
                    $post = isset($pages[$item['slug']]) ? get_post((int) $pages[$item['slug']]) : null;
                    if (!$post || 'trash' === $post->post_status) { continue; }
                    ?>
                    <tr>
                        <td><?php echo esc_html($item['title']); ?></td>
                        <td><?php echo esc_html(get_post_status_object($post->post_status)->label); ?></td>
                        <td><a href="<?php echo esc_url(get_edit_post_link($post->ID)); ?>">Modifier</a> · <a target="_blank" rel="noopener" href="<?php echo esc_url(oasis_demo_page_url($item['slug'])); ?>">Prévisualiser</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <h2>Modification</h2>
        <p>Dans Pages, ouvrez une page et modifiez les blocs, les textes, les photos ou les boutons. Les compositions « Oasis de Bornos » sont également disponibles dans l’éditeur.</p>
        <p>Le formulaire sert uniquement à la démonstration. Aucun e-mail n’est envoyé. Pour un site final, le prestataire devra raccorder un formulaire et valider les textes commerciaux et légaux.</p>
    </div>
    <?php
}

/** Import core shared by the explicit admin action and local verification. */
function oasis_demo_import_pages() {
    if (!current_user_can('manage_options') || !current_user_can('edit_pages')) {
        return new WP_Error('forbidden', 'Droits insuffisants.');
    }
    $pages = get_option('oasis_demo_pages', array());
    $fill = array();
    foreach (oasis_demo_manifest() as $item) {
        $slug = $item['slug'];
        $post = isset($pages[$slug]) ? get_post((int) $pages[$slug]) : null;
        if ($post && 'trash' !== $post->post_status) {
            if ('draft' === $post->post_status && '' === $post->post_content && !get_post_meta($post->ID, '_oasis_demo_complete', true)) {
                $fill[$slug] = $post->ID;
            }
            continue;
        }
        $id = wp_insert_post(array(
            'post_type' => 'page',
            'post_title' => $item['title'],
            'post_name' => $slug,
            'post_status' => 'draft',
            'post_author' => get_current_user_id(),
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'meta_input' => array('_oasis_demo_source' => $slug),
        ), true);
        if (is_wp_error($id)) {
            return $id;
        }
        $pages[$slug] = $id;
        $fill[$slug] = $id;
        update_option('oasis_demo_pages', $pages, false);
    }
    foreach (oasis_demo_manifest() as $item) {
        if (!isset($fill[$item['slug']])) { continue; }
        $id = $fill[$item['slug']];
        $result = wp_update_post(wp_slash(array(
            'ID' => $id,
            'post_content' => oasis_demo_content($item['file']),
        )), true);
        if (is_wp_error($result)) {
            return $result;
        }
        update_post_meta($id, '_oasis_demo_complete', 1);
    }
    return count($fill);
}

add_action('admin_post_oasis_demo_import', function () {
    if (!current_user_can('manage_options') || !current_user_can('edit_pages')) {
        wp_die('Droits insuffisants.', '', array('response' => 403));
    }
    check_admin_referer('oasis_demo_import');
    $result = oasis_demo_import_pages();
    $message = is_wp_error($result) ? 'Import interrompu : ' . $result->get_error_message() : sprintf('%d page(s) créée(s) en brouillon. Aucune publication.', $result);
    set_transient('oasis_demo_result_' . get_current_user_id(), $message, 120);
    wp_safe_redirect(admin_url('themes.php?page=oasis-demo'));
    exit;
});
