# L’Oasis de Bornos — maquette WordPress

Version 1.2 — 29 septembre 2026.

Cette version contient 17 pages. Elle reprend les textes, photographies, couleurs,
la police Futura et les principaux agencements du site oasisdebornos.com.
Les pages des séjours et les cinq formulaires ont été reconstruits séparément.

## Consulter la maquette sans hébergement

Ouvrir `Oasis-de-Bornos-Maquette.html` dans un navigateur après téléchargement.
Le fichier est autonome : photographies, polices et navigation sont incluses.
Aucune mise en ligne n’est nécessaire. Les formulaires ne transmettent rien.

## Installer et modifier dans WordPress

Utiliser une installation WordPress de test, autorisant l’installation de thèmes
ZIP. Le thème demande WordPress 6.6 minimum et PHP 8.0 minimum.

1. Dans **Apparence → Thèmes → Ajouter un thème → Téléverser un thème**, sélectionner
   `Oasis-de-Bornos-WordPress.zip`, puis installer et activer le thème.
2. Ouvrir **Apparence → Maquette Oasis** et cliquer sur **Importer les pages en brouillon**.
3. Dans cette même page, cliquer sur **Prévisualiser** en face d’**Accueil** pour
   parcourir la maquette. Les liens relient les brouillons entre eux.
4. Cliquer sur **Modifier** pour changer les textes, images, boutons et groupes
   dans l’éditeur de blocs WordPress. L’en-tête et le pied de page se modifient
   dans **Apparence → Éditeur**.

L’import crée uniquement des brouillons, sans remplacer les pages existantes,
sans définir une page d’accueil et sans changer la visibilité du site.
Un second import ne crée pas de doublons. Les pages déjà modifiées ne sont pas
écrasées. L’activation d’un thème change en revanche l’apparence globale de
l’installation WordPress : utiliser le WordPress de test pour cette présentation.

Les paragraphes d’introduction des réservations sont des blocs éditables. Les
champs de formulaire sont regroupés dans un bloc HTML, avec un script de
démonstration qui empêche tout envoi. Pour recevoir des demandes réelles, le
prestataire devra remplacer ce bloc par un formulaire connecté.

## Parcours vérifiés

| Départ | Destination de la maquette |
|---|---|
| Découverte de l’Andalousie — 5 nuits | `reserversqg` |
| Découverte de l’Andalousie — 7 nuits | `copie-de-reserversda5n` |
| Découverte Qi Gong — 5 nuits | `sejour-4jours-5nuits` puis `reserversbe` |
| Découverte Qi Gong — 7 nuits | `sejour-6jours-7nuits` puis `reserversd` |
| Location de la maison | `copie-de-reserversda5n-1` |

Les quatre cartes de dates du séjour Qi Gong de 5 nuits et les six cartes du
séjour de 7 nuits renvoient chacune au formulaire de leur séjour. Les deux
fiches possèdent aussi leur bouton de demande d’information en haut de page.

## Écarts présents dans le site source, conservés pour validation

Les informations ci-dessous proviennent de pages différentes du site actuel.
Elles n’ont pas été harmonisées arbitrairement pendant la reproduction.

| Sujet | Fiche ou page « Les Séjours » | Formulaire |
|---|---|---|
| Qi Gong, 7 nuits : chambre partagée | 780 € dans les offres ; 680 € dans la fiche détaillée | 680 € |
| Qi Gong, 7 nuits : chambre individuelle | 925 € dans les offres | 920 € |
| Qi Gong, 7 nuits : session du 18 au 25 | Juin 2026 sur la fiche détaillée | Avril 2026 dans les choix du formulaire |
| Découverte, 7 nuits : quatrième excursion | Vejer de la Frontera | Jerez de la Frontera |
| Qi Gong, 5 nuits : excursions | L’offre annonce 3 excursions et cite 4 villes | Le formulaire cite Séville, Cadix et Ronda |

Les dates 2026, les formulations et les tarifs ont été conservés depuis les
sources. La mention d’hébergement dans les informations légales reste à compléter
pour l’installation finale. La maquette peut être présentée telle quelle ; les
points ci-dessus sont à faire arbitrer par le propriétaire avant une publication.

## Vérification réalisée

- 17 pages contrôlées à 1 440 px et à 390 px de largeur, sans débordement horizontal.
- Aucune image manquante ni erreur JavaScript dans la maquette autonome.
- 17 boutons des offres, des fiches de dates et de la maison cliqués jusqu’à leur
  destination ; aucune cible interne manquante.
- Navigation mobile, sous-menu Qi Gong et formulaire de démonstration vérifiés.
- Import exécuté sur un WordPress local temporaire : 17 brouillons créés ; second
  import : 0 création ; visibilité de l’installation inchangée.

La version HTML ne remplace pas un service de réservation et n’est pas publiée.
